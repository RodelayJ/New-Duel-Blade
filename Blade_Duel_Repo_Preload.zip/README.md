# Blade Duel: Mythic Master — Preloaded Repo

This repo contains all code, assets, audio, and setup for deploying Blade Duel without edits.